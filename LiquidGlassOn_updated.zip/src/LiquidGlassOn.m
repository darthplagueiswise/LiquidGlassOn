/*
 * LiquidGlassOn.m
 *
 * This Objective‑C source file forces the “Liquid Glass” feature on
 * WhatsApp by seeding a preference flag into the appropriate App
 * Group containers and by swizzling the `+[WDSLiquidGlass isEnabled]`
 * class method. When the dynamic library is loaded into WhatsApp the
 * `LG_isEnabled` hook always returns `YES`, ensuring that the
 * feature remains enabled regardless of the persisted settings.
 *
 *  - The `lg_boot` constructor runs at load time and writes
 *    `WAOverrideLiquidGlassEnabled=YES` into both the normal and
 *    business variants of WhatsApp’s shared and private App Groups.
 *
 *  - It also applies a method swizzle so that any calls to
 *    `+[WDSLiquidGlass isEnabled]` always return `YES`.
 */

#import <Foundation/Foundation.h>
#import <objc/runtime.h>

/*
 * Replacement implementation for +[WDSLiquidGlass isEnabled].
 * This function always returns YES, guaranteeing that the Liquid
 * Glass feature is considered enabled.
 */
static BOOL LG_isEnabled(id self, SEL _cmd) {
    return YES;
}

/*
 * Constructor that runs when the dynamic library is loaded. It seeds
 * the override flag into the possible WhatsApp suite identifiers and
 * performs the method swizzle.
 */
__attribute__((constructor))
static void lg_boot(void) {
    @autoreleasepool {
        // 1) Semeia a override nos possíveis suites (WhatsApp normal e Business)
        NSArray<NSString *> *suites = @[@"group.net.whatsapp.WhatsApp.shared",
                                        @"group.net.whatsapp.WhatsApp.private",
                                        @"group.net.whatsapp.WhatsAppSMB.shared",
                                        @"group.net.whatsapp.WhatsAppSMB.private"];
        for (NSString *suite in suites) {
            NSUserDefaults *ud = [[NSUserDefaults alloc] initWithSuiteName:suite];
            if (ud) {
                [ud setBool:YES forKey:@"WAOverrideLiquidGlassEnabled"];
                [ud synchronize];
            }
        }
        // Fallback: domínio padrão também
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"WAOverrideLiquidGlassEnabled"];
        [[NSUserDefaults standardUserDefaults] synchronize];

        // 2) Swizzle suave: +[WDSLiquidGlass isEnabled] -> sempre YES
        Class cls = objc_getClass("WDSLiquidGlass");
        if (cls) {
            SEL sel = sel_registerName("isEnabled");
            Method m = class_getClassMethod(cls, sel);
            if (m) {
                IMP newImp = (IMP)LG_isEnabled;
                method_setImplementation(m, newImp);
            }
        }
    }
}